Informe IA
Presentado por:
Kevin David Rodríguez Belalcazar 1841109
Julián Andrés Salamanca Tellez 1841654
Andrés Felipe Giron Perez 1842504